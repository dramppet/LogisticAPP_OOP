class Engine:
    def __init__(self, command_factory):
        self.command_factory = command_factory

    def start(self):
        print("Приложението е стартирано. Напишете 'exit' за край.")
        while True:
            cmd_line = input(">>> ").strip()
            if cmd_line.lower() in ("exit", "quit"):
                print("Изход.")
                break

            command = self.command_factory.create_command(cmd_line)
            if command:
                result = command.execute()
                if result:
                    print(result)
            else:
                print("Непозната команда.")
